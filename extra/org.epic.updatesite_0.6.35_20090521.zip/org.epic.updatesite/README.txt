This archive contains an update site which can be used for an offline
installation of EPIC. You can add this site in Eclipse using
Help > Software Updates > Find and Install... > Search for new features
to install > New Local Site... After that, browse the site and install
the contained EPIC feature.
